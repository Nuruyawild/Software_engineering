//    ______
//   /_  __/___  ____ ___  ___  ____
//    / / / __ \/ __ `__ \/ _ \/ __ \
//   / / / /_/ / / / / / /  __/ /_/ /
//  /_/  \____/_/ /_/ /_/\___/\____/
//              video for sports enthusiasts...
//
//  2811 cw3 : twak 11/11/2021
//

#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include "the_player.h"
#include "the_button.h"
// read in videos and thumbnails to this directory
std::vector<TheButtonInfo> getInfoIn (std::string loc) {

    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
    QDir dir(QString::fromStdString(loc) );
    QDirIterator it(dir);

    while (it.hasNext()) { // for all files

        QString f = it.next();

            if (f.contains("."))

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
#endif

            QString thumb = f.left( f .length() - 4) +".png";
            if (QFile(thumb).exists()) { // if a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read(); // read the thumbnail
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
                    }
                    else
                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
            }
            else
                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
        }
    }

    return out;
}


int main(int argc, char *argv[]) {

    // let's just check that Qt is operational first
    qDebug() << "Qt version: " << QT_VERSION_STR << endl;

    // create the Qt Application
    QApplication app(argc, argv);

    // collect all the videos in the folder
    std::vector<TheButtonInfo> videos;

    if (argc == 2)
        videos = getInfoIn( std::string(argv[1]) );

    if (videos.size() == 0) {

        const int result = QMessageBox::question(
                    NULL,
                    QString("Tomeo"),
                    QString("no videos found! download, unzip, and add command line argument to \"quoted\" file location. Download videos from Tom's OneDrive?"),
                    QMessageBox::Yes |
                    QMessageBox::No );

        switch( result )
        {
        case QMessageBox::Yes:
          QDesktopServices::openUrl(QUrl("https://leeds365-my.sharepoint.com/:u:/g/personal/scstke_leeds_ac_uk/EcGntcL-K3JOiaZF4T_uaA4BHn6USbq2E55kF_BTfdpPag?e=n1qfuN"));
          break;
        default:
            break;
        }
        exit(-1);
    }

    // the widget that will show the video
    QVideoWidget *videoWidget = new QVideoWidget;
    QSlider* progressbar;//Video progress bar
    QSlider* volumebar; //Video Volume bar

    progressbar = new QSlider(Qt::Horizontal);
    volumebar = new QSlider(Qt::Horizontal);
    progressbar->setMinimumWidth(200);
    volumebar->setMinimumWidth(150);


    // the QMediaPlayer which controls the playback
    ThePlayer *player = new ThePlayer;
    player->setVideoOutput(videoWidget);
    player->setVolume(100);


    // a row of buttons
    QWidget *buttonWidget = new QWidget();
    // a list of the buttons
    std::vector<TheButton*> buttons;
    // the buttons are arranged horizontally
    QVBoxLayout *layout = new QVBoxLayout();
    buttonWidget->setLayout(layout);



    // create the four buttons
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    // tell the player what buttons and videos are available
    player->setContent(&buttons, & videos);
    player->setPlaybackRate(0.25);

    // create the main window and layout
    QWidget window;

    // Buttons
    QPushButton *buttonpause = new QPushButton;
    buttonpause ->setIcon(buttonpause ->style()->standardIcon(QStyle::SP_MediaPause));
    buttonpause ->setIconSize(QSize(40, 40));
    buttonpause ->connect(buttonpause , &QPushButton::clicked, player, &QMediaPlayer::pause);


    QPushButton *buttonplay = new QPushButton;
    buttonplay ->setIcon(buttonplay->style()->standardIcon(QStyle::SP_MediaPlay));
    buttonplay ->setIconSize(QSize(40, 40));
    buttonplay ->connect(buttonplay, &QPushButton::clicked, player, &QMediaPlayer::play);

    QPushButton *buttonback = new QPushButton;
    buttonback->setIcon(buttonback->style()->standardIcon(QStyle::SP_MediaSkipBackward));
    buttonback->setIconSize(QSize(40, 40));
    buttonback->connect(buttonback, &QPushButton::clicked, player, &QMediaPlayer::play);

    QPushButton *buttonforward = new QPushButton;
    buttonforward ->setIcon(buttonforward->style()->standardIcon(QStyle::SP_MediaSkipForward));
    buttonforward ->setIconSize(QSize(40, 40));
    buttonforward ->connect(buttonforward, &QPushButton::clicked, player, &QMediaPlayer::play);

    QPushButton *buttonvol = new QPushButton;
    buttonvol->setIcon(buttonvol->style()->standardIcon(QStyle::SP_MediaVolumeMuted));
    buttonvol->setIconSize(QSize(40, 40));
    buttonvol->setCheckable(true);
    buttonvol->connect(buttonvol, &QPushButton::clicked, player, &QMediaPlayer::setMuted);

    //progress
    QLCDNumber* timenumber;
    timenumber = new QLCDNumber(5);
    timenumber->setMaximumHeight(30);

    QComboBox * speed = new QComboBox;
    speed->addItem("0.5x", QVariant(0.5));
    speed->addItem("1x", QVariant(1));
    speed->addItem("1.5x", QVariant(1.5));
    speed->addItem("2x", QVariant(2));
    speed->addItem("2.5x", QVariant(2.5));
    speed->addItem("3x", QVariant(3));
    speed->setCurrentIndex(1);
    speed->setMaximumWidth(80);
    speed->connect(speed, QOverload<int>::of(&QComboBox::activated), player, &QMediaPlayer::setPlaybackRate);


    QIcon *ico = new QIcon();
       ico->addPixmap(QPixmap("icons/mute.png"),QIcon::Normal,QIcon::On);
       ico->addPixmap(QPixmap("icons/pause.png"),QIcon::Normal,QIcon::Off);



    player->connect(player, &QMediaPlayer::durationChanged, progressbar, &QSlider::setMaximum);
    player->connect(player, &QMediaPlayer::positionChanged, progressbar, &QSlider::setValue);
    //two bar
    progressbar->connect(progressbar, &QSlider::sliderMoved, player, &QMediaPlayer::setPosition);
    progressbar->connect(progressbar, SIGNAL(valueChanged(int)), timenumber, SLOT(display(int)));
    volumebar->connect(volumebar, &QSlider::sliderMoved, player, &QMediaPlayer::setVolume);

    //video progress area
    QHBoxLayout *progress = new QHBoxLayout;
    progress->addWidget(timenumber);
    progress->addWidget(progressbar);
    progress->addWidget(speed);

    //button area at bottom
    QHBoxLayout *butlayout = new QHBoxLayout;
    butlayout->setSpacing(50);

    butlayout->addStretch(3);
    butlayout->addWidget(buttonback);
    butlayout->addWidget(buttonpause);
    butlayout->addWidget(buttonplay);
    butlayout->addWidget(buttonforward);
    butlayout->addStretch(2);
    butlayout->addWidget(buttonvol);
    butlayout->addWidget(volumebar);

    //button stretch
    butlayout->setStretchFactor(buttonback,1);
    butlayout->setStretchFactor(buttonforward,1);
    butlayout->setStretchFactor(buttonpause ,2);
    butlayout->setStretchFactor(buttonplay,2);


    QVBoxLayout *mainlayout = new QVBoxLayout();
    QVBoxLayout *mainvedio = new QVBoxLayout(); //playing vedio and progress at left
    QHBoxLayout *videoarea = new QHBoxLayout();//playing vedio and vedio list at right
    window.setLayout(mainlayout);
    window.setWindowTitle("tomeo");
    window.setMinimumSize(700, 400);


    // add the video and the buttons to the vedioarea
    QScrollArea *scrollArea = new QScrollArea;
    scrollArea->setWidgetResizable(true);
    scrollArea->setWidget(buttonWidget);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setMinimumWidth(200);

    mainvedio->addWidget(videoWidget);
    mainvedio->addLayout(progress);

    videoarea->addLayout(mainvedio);
    videoarea->addWidget(scrollArea);

    mainlayout->addLayout(videoarea);
    mainlayout->addLayout(butlayout);





    // showtime!
    window.show();

    // wait for the app to terminate
    return app.exec();
}
