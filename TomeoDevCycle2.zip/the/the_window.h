#ifndef THE_WINDOW_H
#define THE_WINDOW_H
#include <QMainWindow>
#include <QWidget>
#include <QLayout>
#include <QLabel>
#include <QActionGroup>
#include <QMenuBar>
#include <QTableWidget>
#include <string>
#include <vector>

#include "the_player.h"


QMenu *prefMenu;
QMenu *exportMenu;
QMenu *toolsMenu;
QMenu *helpMenu;
QAction *editPrefAct;
QAction *saveLayoutAct;
QAction *exportToFolderAct;
QAction *exportToSocialMediaAct;
QAction *toolsSelectAct;
QAction *viewDocsAct;
QAction *searchHelpAct;




#endif // THE_WINDOW_H
