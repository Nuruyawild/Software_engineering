//    ______
//   /_  __/___  ____ ___  ___  ____
//    / / / __ \/ __ `__ \/ _ \/ __ \
//   / / / /_/ / / / / / /  __/ /_/ /
//  /_/  \____/_/ /_/ /_/\___/\____/
//              video for sports enthusiasts...
//
//  2811 cw3 : twak 11/11/2021
//

#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include "the_player.h"
#include "the_button.h"

// read in videos and thumbnails to this directory
std::vector<TheButtonInfo> getInfoIn (std::string loc) {

    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
    QDir dir(QString::fromStdString(loc) );
    QDirIterator it(dir);

    while (it.hasNext()) { // for all files

        QString f = it.next();

            if (f.contains("."))

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
#endif

            QString thumb = f.left( f .length() - 4) +".png";
            if (QFile(thumb).exists()) { // if a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read(); // read the thumbnail
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
                    }
                    else
                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
            }
            else
                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
        }
    }

    return out;
}

qint64 getAudioTime(const QString &filePath)
{
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly)) {
        qint64 fileSize = file.size();
        qint64 time = fileSize / (16000.0 * 2.0);
        file.close();
        return time;
    }
    return -1;
}

QPushButton *PausePlay;
void ThePlayer::toggleState(){
    if(playing == true){
        pause();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
        playing = false;
    }else{
        play();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPause));
        playing = true;
    }
}

int main(int argc, char *argv[]) {

    // let's just check that Qt is operational first
    qDebug() << "Qt version: " << QT_VERSION_STR << endl;

    // create the Qt Application
    QApplication app(argc, argv);

    // 声明
    QWidget *centralwidget; // 不用管，Qt designer会用一个widget设计整个布局
    QGridLayout *gridLayout; // 栅格布局，用来实现整体自适应
    QHBoxLayout *horizontalLayout_2; // 四个按钮+音量调节滑轨的布局
    QPushButton *ButtonBack; // 上一个按钮
    // 播放/暂停按钮使用了槽函数，所以定义放在了main之前的函数里
    QPushButton *ButtonForward; // 下一个按钮
    QPushButton *ButtonVolumn; // 静音按钮
    QSlider *horizontalSlider; // 音量调节滑轨
    QVBoxLayout *verticalLayout; // 最右放表格的布局
    QHBoxLayout *Progress; // 播放时间，进度条滑轨和倍速的布局
    QLCDNumber *TimeNumber; // 播放时间显示
    QSlider *horizontalSlider_2; // 进度条
    QComboBox *Speed; // 倍速
    QVBoxLayout *verticalLayout_2; // 最底部播放列表的布局
    QVBoxLayout *InformationLayout; // 标题图片的布局
    QLabel *label; // 标题图片
    QVBoxLayout *VideoWidget; // 视频播放界面的布局
    QMenuBar *menubar; // 顶部工具栏
    QStatusBar *statusbar; // 状态栏，Qt designer自动生成，暂时没用到
    QMainWindow *Main_for3 = new QMainWindow(); // 主窗口

    // collect all the videos in the folder
    std::vector<TheButtonInfo> videos;

    if (argc == 2)
        videos = getInfoIn( std::string(argv[1]) );

    if (videos.size() == 0) {

        const int result = QMessageBox::question(
                    NULL,
                    QString("Tomeo"),
                    QString("no videos found! download, unzip, and add command line argument to \"quoted\" file location. Download videos from Tom's OneDrive?"),
                    QMessageBox::Yes |
                    QMessageBox::No );

        switch( result )
        {
        case QMessageBox::Yes:
          QDesktopServices::openUrl(QUrl("https://leeds365-my.sharepoint.com/:u:/g/personal/scstke_leeds_ac_uk/EcGntcL-K3JOiaZF4T_uaA4BHn6USbq2E55kF_BTfdpPag?e=n1qfuN"));
          break;
        default:
            break;
        }
        exit(-1);
    }

    // the widget that will show the video
    QVideoWidget *videoWidget = new QVideoWidget;

    // the QMediaPlayer which controls the playback
    ThePlayer *player = new ThePlayer;
    player->setVideoOutput(videoWidget);
    player->setVolume(100);

    // a row of buttons
    QWidget *buttonWidget = new QWidget();
    // a list of the buttons
    std::vector<TheButton*> buttons;
    // the buttons are arranged horizontally 这里的视频列表是横着的，4需要改成QVBoxLayout
    QHBoxLayout *layout = new QHBoxLayout();
    buttonWidget->setLayout(layout);

    // create the video list
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    //主窗口布局
    if (Main_for3->objectName().isEmpty())
        Main_for3->setObjectName(QStringLiteral("Main_for3"));
    Main_for3->resize(642, 467);
    centralwidget = new QWidget(Main_for3);
    centralwidget->setObjectName(QStringLiteral("centralwidget"));
    gridLayout = new QGridLayout(centralwidget);
    gridLayout->setObjectName(QStringLiteral("gridLayout"));

    // 标题图片，QLabel居中放在对应的布局中
    InformationLayout = new QVBoxLayout();
    InformationLayout->setObjectName(QStringLiteral("InformationLayout"));
    InformationLayout->setSizeConstraint(QLayout::SetMaximumSize);
    label = new QLabel(centralwidget);
    label->setObjectName(QStringLiteral("label"));
    label->setMaximumHeight(60);
    label->setMinimumHeight(60);
    // The relative path of the file is used.
    // Where "the" represents the name of the folder where the project files are located.
    // And place the required files in "Resources" folder.
    QPixmap *px = new QPixmap("../the/Resources/img1.png");
    *px = px->scaled(700,60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    label->setPixmap(*px);
    label->setAlignment(Qt::AlignHCenter); // 图片在布局中居中
    InformationLayout->addWidget(label);

    // 图片布局放到整体布局中实现自适应
    gridLayout->addLayout(InformationLayout, 0, 0, 1, 1);

    // 视频放在对应的布局中
    VideoWidget = new QVBoxLayout();
    VideoWidget->setObjectName(QStringLiteral("VideoWidget"));
    VideoWidget->addWidget(videoWidget);
    gridLayout->addLayout(VideoWidget, 1, 0, 1, 1);

    // 播放时间，放在对应的布局中
    Progress = new QHBoxLayout();
    Progress->setObjectName(QStringLiteral("Progress"));
    TimeNumber = new QLCDNumber();
    TimeNumber->setObjectName(QStringLiteral("TimeNumber"));
    TimeNumber = new QLCDNumber(5);
    TimeNumber->setMaximumHeight(30);
    Progress->addWidget(TimeNumber);

    // 进度条，放在对应的布局中
    horizontalSlider_2 = new QSlider(centralwidget);
    horizontalSlider_2->setObjectName(QStringLiteral("horizontalSlider_2"));
    horizontalSlider_2->setOrientation(Qt::Horizontal);
    player->connect(player, &QMediaPlayer::durationChanged, horizontalSlider_2, &QSlider::setMaximum);
    player->connect(player, &QMediaPlayer::positionChanged, horizontalSlider_2, &QSlider::setValue);
    horizontalSlider_2->connect(horizontalSlider_2, &QSlider::sliderMoved, player, &QMediaPlayer::setPosition);
    horizontalSlider_2->connect(horizontalSlider_2, SIGNAL(valueChanged(int)), TimeNumber, SLOT(display(int)));
    Progress->addWidget(horizontalSlider_2);

    // 倍速，放在对应的布局中
    Speed = new QComboBox(centralwidget);
    Speed->setObjectName(QStringLiteral("Speed"));
    Speed->addItem("0.5x", QVariant(0.5));
    Speed->addItem("1x", QVariant(1));
    Speed->addItem("1.5x", QVariant(1.5));
    Speed->addItem("2x", QVariant(2));
    Speed->addItem("2.5x", QVariant(2.5));
    Speed->addItem("3x", QVariant(3));
    Speed->setCurrentIndex(1);
    Speed->setMaximumWidth(80);
    Speed->connect(Speed, QOverload<int>::of(&QComboBox::activated), player, &QMediaPlayer::setPlaybackRate);
    Progress->addWidget(Speed);

    // 对应布局放到整体布局中实现响应式布局
    gridLayout->addLayout(Progress, 2, 0, 1, 1);

    // 后退按钮，放在对应的布局中
    horizontalLayout_2 = new QHBoxLayout();
    horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
    horizontalLayout_2->addStretch(1);
    ButtonBack = new QPushButton(centralwidget);
    ButtonBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonBack->setIcon(ButtonBack->style()->standardIcon(QStyle::SP_MediaSkipBackward));
    ButtonBack->setIconSize(QSize(40, 40));
    ButtonBack->connect(ButtonBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonBack);

    // 播放/暂停按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    PausePlay = new QPushButton();
    PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
    PausePlay ->setIconSize(QSize(40, 40));
    PausePlay->connect(PausePlay, SIGNAL (clicked()), player, SLOT(toggleState()));
    horizontalLayout_2->addWidget(PausePlay);

    // 前进按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonForward = new QPushButton(centralwidget);
    ButtonForward->setObjectName(QStringLiteral("ButtonForward"));
    ButtonForward ->setIcon(ButtonForward->style()->standardIcon(QStyle::SP_MediaSkipForward));
    ButtonForward ->setIconSize(QSize(40, 40));
    ButtonForward ->connect(ButtonForward, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonForward);

    // 静音按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonVolumn = new QPushButton(centralwidget);
    ButtonVolumn->setObjectName(QStringLiteral("ButtonVolumn"));
    ButtonVolumn->setIcon(ButtonVolumn->style()->standardIcon(QStyle::SP_MediaVolumeMuted));
    ButtonVolumn->setIconSize(QSize(40, 40));
    ButtonVolumn->setCheckable(true);
    ButtonVolumn->connect(ButtonVolumn, &QPushButton::clicked, player, &QMediaPlayer::setMuted);
    horizontalLayout_2->addWidget(ButtonVolumn);

    //音量调节按钮，放在对应的布局中
    horizontalSlider = new QSlider(centralwidget);
    horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
    horizontalSlider->setOrientation(Qt::Horizontal);
    horizontalSlider->connect(horizontalSlider, &QSlider::sliderMoved, player, &QMediaPlayer::setVolume);
    horizontalLayout_2->addWidget(horizontalSlider);

    //把播放等按钮的布局放在整体布局中实现自适应
    gridLayout->addLayout(horizontalLayout_2, 3, 0, 1, 1);

    // create the video list buttons
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    // tell the player what buttons and videos are available
    player->setContent(&buttons, & videos);
    player->setPlaybackRate(0.25);

    // add the video and the buttons to the vedioarea
    QScrollArea *scrollArea = new QScrollArea;
    scrollArea->setWidgetResizable(true);
    scrollArea->setWidget(buttonWidget);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scrollArea->setMaximumHeight(180);
    scrollArea->setMinimumHeight(180);

    // 把视频播放列表布局放到整体布局中实现自适应
    verticalLayout_2 = new QVBoxLayout();
    verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
    verticalLayout_2->addWidget(scrollArea);
    gridLayout->addLayout(verticalLayout_2, 4, 0, 1, 1);

    // add a table
    verticalLayout = new QVBoxLayout();
    verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
    QTableWidget *tableWidget = new QTableWidget(7,2);
    QStringList header;
    header<<"Month"<<"Description";
    tableWidget->setHorizontalHeaderLabels(header);
    tableWidget->setItem(0,0,new QTableWidgetItem("Author"));
    tableWidget->setItem(1,0,new QTableWidgetItem("Time"));
    tableWidget->setItem(2,0,new QTableWidgetItem("Location"));
    tableWidget->setItem(3,0,new QTableWidgetItem("Activity"));
    tableWidget->setItem(0,1,new QTableWidgetItem("Tom"));
    tableWidget->setItem(1,1,new QTableWidgetItem("2021-12-10"));
    tableWidget->setItem(2,1,new QTableWidgetItem("UK"));
    tableWidget->setItem(3,1,new QTableWidgetItem("Bicycle"));
    tableWidget->setMaximumWidth(200);
    tableWidget->setMinimumWidth(200);
    verticalLayout->addWidget(tableWidget);

    // 又在右下放了一个表格
    QTableWidget *tableWidget1 = new QTableWidget(7,2);
    QStringList header1;
    header<<"Month"<<"Description";
    tableWidget1->setHorizontalHeaderLabels(header1);
    tableWidget1->setItem(0,0,new QTableWidgetItem("Author"));
    tableWidget1->setItem(1,0,new QTableWidgetItem("Time"));
    tableWidget1->setItem(2,0,new QTableWidgetItem("Location"));
    tableWidget1->setItem(3,0,new QTableWidgetItem("Activity"));
    tableWidget1->setItem(0,1,new QTableWidgetItem("Tom"));
    tableWidget1->setItem(1,1,new QTableWidgetItem("2021-12-10"));
    tableWidget1->setItem(2,1,new QTableWidgetItem("UK"));
    tableWidget1->setItem(3,1,new QTableWidgetItem("Bicycle"));
    tableWidget1->setMaximumWidth(200);
    tableWidget1->setMinimumWidth(200);
    verticalLayout->addWidget(tableWidget1);

    // 把表格布局放到整体布局中实现自适应
    gridLayout->addLayout(verticalLayout, 0, 1, 5, 1);

    QIcon *ico = new QIcon();
       ico->addPixmap(QPixmap("icons/mute.png"),QIcon::Normal,QIcon::On);
       ico->addPixmap(QPixmap("icons/pause.png"),QIcon::Normal,QIcon::Off);

    // add a menubar on the top.
    QMenu* Menu[10];
    Main_for3->setCentralWidget(centralwidget);
    menubar = new QMenuBar(Main_for3);
    menubar->setObjectName(QStringLiteral("menubar"));
    menubar->setGeometry(QRect(0, 0, 642, 21));
    QAction *Brightness = new QAction("Brightness");
    QAction *Contrast = new QAction("Contrast");
    QAction *Localfile = new QAction("Local file");
    QAction *Externalfile = new QAction("External file");
    QAction *Edit = new QAction("Edit video");
    QAction *Dub = new QAction("Dub for video");
    QAction *Instruction = new QAction("Instruction");
    QAction *Maintance = new QAction("Maintance");
    Menu[0] = new QMenu("Setting");
    Menu[0]->addAction(Brightness);
    Menu[0]->addAction(Contrast);
    Menu[1] = new QMenu("Import");
    Menu[1]->addAction(Localfile);
    Menu[1]->addAction(Externalfile);
    Menu[2] = new QMenu("Tools");
    Menu[2]->addAction(Edit);
    Menu[2]->addAction(Dub);
    Menu[3] = new QMenu("Help");
    Menu[3]->addAction(Instruction);
    Menu[3]->addAction(Maintance);
    menubar->addMenu(Menu[0]);
    menubar->addMenu(Menu[1]);
    menubar->addMenu(Menu[2]);
    menubar->addMenu(Menu[3]);
    Main_for3->setMenuBar(menubar);


    statusbar = new QStatusBar(Main_for3);
    statusbar->setObjectName(QStringLiteral("statusbar"));
    Main_for3->setStatusBar(statusbar);


    // add the video and the buttons to the top level widget


    // showtime!
    Main_for3->show();

    // wait for the app to terminate
    return app.exec();
}
