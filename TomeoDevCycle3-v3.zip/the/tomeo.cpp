//    ______
//   /_  __/___  ____ ___  ___  ____
//    / / / __ \/ __ `__ \/ _ \/ __ \
//   / / / /_/ / / / / / /  __/ /_/ /
//  /_/  \____/_/ /_/ /_/\___/\____/
//              video for sports enthusiasts...
//
//  2811 cw3 : twak 11/11/2021
//

#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include <QtGui>

#include <QFileSystemModel>
#include <QScreen>

#include <QVideoWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QMediaMetaData>
#include <QMediaPlaylist>
#include <QtCore/QDateTime>
#include "the_player.h"
#include "the_button.h"
#include "the_window.h"

//// read in videos and thumbnails to this directory
//std::vector<TheButtonInfo> MainWindow::getInfoIn () {

//    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
//    QDir dir(QString::fromStdString(loc) );
//    QDirIterator it(dir);

//    while (it.hasNext()) { // for all files

//        QString f = it.next();

//            if (f.contains("."))

//#if defined(_WIN32)
//            if (f.contains(".wmv"))  { // windows
//#else
//            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
//#endif

//            QString thumb = f.left( f .length() - 4) +".png";
//            if (QFile(thumb).exists()) { // if a png thumbnail exists
//                QImageReader *imageReader = new QImageReader(thumb);
//                    QImage sprite = imageReader->read(); // read the thumbnail
//                    if (!sprite.isNull()) {
//                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
//                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
//                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
//                    }
//                    else
//                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
//            }
//            else
//                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
//        }
//    }

//    return out;
//}

//qint64 getAudioTime(const QString &filePath)
//{
//    QFile file(filePath);
//    if (file.open(QIODevice::ReadOnly)) {
//        qint64 fileSize = file.size();
//        qint64 time = fileSize / (16000.0 * 2.0);
//        file.close();
//        return time;
//    }
//    return -1;
//}

//QPushButton *PausePlay;
//void ThePlayer::toggleState(){
//    if(playing == true){
//        pause();
//        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
//        playing = false;
//    }else{
//        play();
//        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPause));
//        playing = true;
//    }
//}

int main(int argc, char *argv[]) {

    // let's just check that Qt is operational first
    qDebug() << "Qt version: " << QT_VERSION_STR << endl;

    // create the Qt Application
    QApplication app(argc, argv);


    MainWindow* window = new MainWindow(std::string(argv[1]));
    window->setWindowTitle("Tomeo");
    window->setMinimumSize(800, 680);



    // add the video and the buttons to the top level widget


    // showtime!
    window->show();

    // wait for the app to terminate
    return app.exec();
}
