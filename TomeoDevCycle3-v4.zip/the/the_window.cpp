#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include <QtGui>
#include <QFileSystemModel>
#include <QScreen>
#include <QVideoWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QMediaMetaData>
#include <QMediaPlaylist>
#include <QtCore/QDateTime>
#include <QFormLayout>
#include "the_player.h"
#include "the_button.h"
#include "the_window.h"




MainWindow::MainWindow(std::string path): path(path) {
    videos = getInfoIn();
    createAll();
}


// read in videos and thumbnails to this directory
std::vector<TheButtonInfo> MainWindow::getInfoIn () {

    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
    QDir dir(QString::fromStdString(path) );
    QDirIterator it(dir);

    while (it.hasNext()) { // for all files

        QString f = it.next();

            if (f.contains("."))

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
#endif

            QString thumb = f.left( f .length() - 4) +".png";
            if (QFile(thumb).exists()) { // if a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read(); // read the thumbnail
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
                    }
                    else
                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
            }
            else
                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
        }
    }

    return out;
}



qint64 getAudioTime(const QString &filePath)
{
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly)) {
        qint64 fileSize = file.size();
        qint64 time = fileSize / (16000.0 * 2.0);
        file.close();
        return time;
    }
    return -1;
}

QPushButton *PausePlay;
void ThePlayer::toggleState(){
    if(playing == true){
        pause();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
        playing = false;
    }else{
        play();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPause));
        playing = true;
    }
}

// 菜单栏中update的弹窗
void MainWindow::Update() {

    QVBoxLayout* lay = new QVBoxLayout;

    QLabel *label_text = new QLabel;
//    QLabel *label_button = new QLabel;
    //QPixmap pm(":/help.png"); // <- path to image file
    //label->setPixmap(pm);
    label_text->setScaledContents(true);
    label_text->setMaximumSize(700,400);
    label_text->setText("<em><strong>Please choose the version you want to update to:<\strong><\em>");

    QPushButton *version1 = new QPushButton("1.1.2");
    QPushButton *version2 = new QPushButton("1.1.3");
    QPushButton *version3 = new QPushButton("1.2.1");
    QHBoxLayout *hor_text = new QHBoxLayout;
    hor_text->addWidget(label_text);
    QHBoxLayout *hor_button = new QHBoxLayout;
    hor_button->setMargin(0);
    hor_button->addWidget(version1);
    hor_button->addWidget(version2);
    hor_button->addWidget(version3);

    lay->addLayout(hor_text);
    lay->addLayout(hor_button);
    //lay->addWidget(label_text);
//    lay->addWidget(label_button);
    lay->setMargin(20);
    lay->setSpacing(15);
    QDialog dialog(this);
    dialog.setModal(true);
    dialog.setLayout(lay);
    dialog.setWindowTitle("Update");
    dialog.setWindowFlags(windowFlags()&~Qt::WindowContextHelpButtonHint);
    dialog.exec();
}


//菜单栏中setting的弹窗
void MainWindow::setting() {

    QSlider *bri_setting = new QSlider(Qt::Horizontal);
    bri_setting->setRange(-100, 100);
    QLabel *bri_label=new QLabel;
    bri_label->setText("Brightness");


    QSlider *contrast_setting = new QSlider(Qt::Horizontal);
    contrast_setting->setRange(-100, 100);
    QLabel *con_label=new QLabel;
    con_label->setText("Contrast");

    QSlider *hue_setting = new QSlider(Qt::Horizontal);
    hue_setting->setRange(-100, 100);
    QLabel *hue_label=new QLabel;
    hue_label->setText("Hue");

    QGridLayout *settinglayout = new QGridLayout;
    QLabel *setting_title=new QLabel;
    setting_title->setText("<em><strong>Setting Your Video Attribute<\strong><\em>");
    settinglayout->addWidget(setting_title,0,1,1,4);
    settinglayout->addWidget(hue_label,1,0,1,2);
    settinglayout->addWidget(con_label,2,0,1,2);
    settinglayout->addWidget(bri_label,3,0,1,2);
    settinglayout->addWidget(hue_setting,1,2,1,5);
    settinglayout->addWidget(contrast_setting,2,2,1,5);
    settinglayout->addWidget(bri_setting,3,2,1,5);

    QDialog *video_setDialog = new QDialog;
    video_setDialog->setWindowTitle(tr("Video Attribute Setting"));
    video_setDialog->setWindowFlags(windowFlags()&~Qt::WindowContextHelpButtonHint);
    video_setDialog->setLayout(settinglayout);
    video_setDialog->exec();

}


void MainWindow::createAll(){
//    QMainWindow *Main_for3 = new QMainWindow(); // 主窗口

    // the widget that will show the video
    QVideoWidget *videoWidget = new QVideoWidget;

    // the QMediaPlayer which controls the playback
    ThePlayer *player = new ThePlayer;
    player->setVideoOutput(videoWidget);
    player->setVolume(100);

    // a row of buttons
    QWidget *buttonWidget = new QWidget();
    // a list of the buttons
//    std::vector<TheButton*> buttons;
    // the buttons are arranged horizontally 这里的视频列表是横着的，4需要改成QVBoxLayout
    QHBoxLayout *layout = new QHBoxLayout();
    buttonWidget->setLayout(layout);

    // create the video list
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    //主窗口布局
    if (this->objectName().isEmpty())
        this->setObjectName(QStringLiteral("Main_for3"));
    this->resize(642, 467);
    centralwidget = new QWidget(this);
    centralwidget->setObjectName(QStringLiteral("centralwidget"));
    gridLayout = new QGridLayout(centralwidget);
    gridLayout->setObjectName(QStringLiteral("gridLayout"));

    // 标题图片，QLabel居中放在对应的布局中
    InformationLayout = new QVBoxLayout();
    InformationLayout->setObjectName(QStringLiteral("InformationLayout"));
    InformationLayout->setSizeConstraint(QLayout::SetMaximumSize);
    label = new QLabel(centralwidget);
    label->setObjectName(QStringLiteral("label"));
    // The relative path of the file is used.
    // Where "the" represents the name of the folder where the project files are located.
    // And place the required files in "Resources" folder.
    QPixmap *px = new QPixmap("../the/Resources/img1.png");
    *px = px->scaled(700,60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    label->setPixmap(*px);
    label->setAlignment(Qt::AlignHCenter); // 图片在布局中居中
    InformationLayout->addWidget(label);

    // 图片布局放到整体布局中实现自适应
    gridLayout->addLayout(InformationLayout, 0, 0, 1, 1);

    // 视频放在对应的布局中
    VideoWidget = new QVBoxLayout();
    VideoWidget->setObjectName(QStringLiteral("VideoWidget"));
    VideoWidget->addWidget(videoWidget);
    gridLayout->addLayout(VideoWidget, 1, 0, 1, 1);

    // 播放时间，放在对应的布局中
    Progress = new QHBoxLayout();
    Progress->setObjectName(QStringLiteral("Progress"));
    TimeNumber = new QLCDNumber();
    TimeNumber->setObjectName(QStringLiteral("TimeNumber"));
    TimeNumber = new QLCDNumber(5);
    TimeNumber->setMaximumHeight(30);
    Progress->addWidget(TimeNumber);

    // 进度条，放在对应的布局中
    horizontalSlider_2 = new QSlider(centralwidget);
    horizontalSlider_2->setObjectName(QStringLiteral("horizontalSlider_2"));
    horizontalSlider_2->setOrientation(Qt::Horizontal);
    player->connect(player, &QMediaPlayer::durationChanged, horizontalSlider_2, &QSlider::setMaximum);
    player->connect(player, &QMediaPlayer::positionChanged, horizontalSlider_2, &QSlider::setValue);
    horizontalSlider_2->connect(horizontalSlider_2, &QSlider::sliderMoved, player, &QMediaPlayer::setPosition);
    horizontalSlider_2->connect(horizontalSlider_2, SIGNAL(valueChanged(int)), TimeNumber, SLOT(display(int)));
    Progress->addWidget(horizontalSlider_2);

    // 对应布局放到整体布局中实现响应式布局
    gridLayout->addLayout(Progress, 2, 0, 1, 1);

    // 倍速，放在对应的布局中
    Speed = new QComboBox(centralwidget);
    Speed->setObjectName(QStringLiteral("Speed"));
    Speed->addItem("0.5x", QVariant(0.5));
    Speed->addItem("1x", QVariant(1));
    Speed->addItem("1.5x", QVariant(1.5));
    Speed->addItem("2x", QVariant(2));
    Speed->addItem("2.5x", QVariant(2.5));
    Speed->addItem("3x", QVariant(3));
    Speed->setCurrentIndex(1);
    Speed->setMaximumWidth(80);
    Speed->connect(Speed, QOverload<int>::of(&QComboBox::activated), player, &QMediaPlayer::setPlaybackRate);
    Progress->addWidget(Speed);

    // 后退按钮，放在对应的布局中

    horizontalLayout_2 = new QHBoxLayout();
    horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->addStretch(1);
    ButtonBack = new QPushButton(centralwidget);
    ButtonBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonBack->setIcon(ButtonBack->style()->standardIcon(QStyle::SP_MediaSkipBackward));
    ButtonBack->setIconSize(QSize(40, 40));
    ButtonBack->connect(ButtonBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonBack);

    //切换上一个视频按钮
    horizontalLayout_2->addStretch(1);
    ButtonSeekBack = new QPushButton(centralwidget);
    ButtonSeekBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonSeekBack->setIcon(ButtonSeekBack->style()->standardIcon(QStyle::SP_MediaSeekBackward));
    ButtonSeekBack->setIconSize(QSize(40, 40));
    ButtonSeekBack->connect(ButtonSeekBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonSeekBack);


    // 播放/暂停按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    PausePlay = new QPushButton();
    PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
    PausePlay ->setIconSize(QSize(40, 40));
    PausePlay->connect(PausePlay, SIGNAL (clicked()), player, SLOT(toggleState()));
    horizontalLayout_2->addWidget(PausePlay);

    //切换到下一个视频按钮
    horizontalLayout_2->addStretch(2);
    ButtonSeekBack = new QPushButton(centralwidget);
    ButtonSeekBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonSeekBack->setIcon(ButtonSeekBack->style()->standardIcon(QStyle::SP_MediaSeekForward));
    ButtonSeekBack->setIconSize(QSize(40, 40));
    ButtonSeekBack->connect(ButtonSeekBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonSeekBack);

    // 前进按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonForward = new QPushButton(centralwidget);
    ButtonForward->setObjectName(QStringLiteral("ButtonForward"));
    ButtonForward ->setIcon(ButtonForward->style()->standardIcon(QStyle::SP_MediaSkipForward));
    ButtonForward ->setIconSize(QSize(40, 40));
    ButtonForward ->connect(ButtonForward, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonForward);

    // 静音按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonVolumn = new QPushButton(centralwidget);
    ButtonVolumn->setObjectName(QStringLiteral("ButtonVolumn"));
    ButtonVolumn->setIcon(ButtonVolumn->style()->standardIcon(QStyle::SP_MediaVolumeMuted));
    ButtonVolumn->setIconSize(QSize(40, 40));
    ButtonVolumn->setCheckable(true);
    ButtonVolumn->connect(ButtonVolumn, &QPushButton::clicked, player, &QMediaPlayer::setMuted);
    horizontalLayout_2->addWidget(ButtonVolumn);

    //音量调节按钮，放在对应的布局中
    horizontalSlider = new QSlider(centralwidget);
    horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
    horizontalSlider->setOrientation(Qt::Horizontal);
    horizontalSlider->connect(horizontalSlider, &QSlider::sliderMoved, player, &QMediaPlayer::setVolume);
    horizontalLayout_2->addWidget(horizontalSlider);

    //把播放等按钮的布局放在整体布局中实现自适应
    gridLayout->addLayout(horizontalLayout_2, 3, 0, 1, 1);

    // create the video list buttons
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    // tell the player what buttons and videos are available
    player->setContent(&buttons, & videos);
    player->setPlaybackRate(0.25);

    // add the video and the buttons to the vedioarea
    QScrollArea *scrollArea = new QScrollArea;
    scrollArea->setWidgetResizable(true);
    scrollArea->setWidget(buttonWidget);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scrollArea->setMaximumHeight(180);
    scrollArea->setMinimumHeight(180);

    // 把视频播放列表布局放到整体布局中实现自适应
    verticalLayout_2 = new QVBoxLayout();
    verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
    verticalLayout_2->addWidget(scrollArea);
    gridLayout->addLayout(verticalLayout_2, 4, 0, 1, 1);

    // add a table
    verticalLayout = new QVBoxLayout();
    verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
    QTableWidget *tableWidget = new QTableWidget(7,2);
    QStringList header;
    header<<"Month"<<"Description";
    tableWidget->setHorizontalHeaderLabels(header);
    tableWidget->setItem(0,0,new QTableWidgetItem("Author"));
    tableWidget->setItem(1,0,new QTableWidgetItem("Time"));
    tableWidget->setItem(2,0,new QTableWidgetItem("Location"));
    tableWidget->setItem(3,0,new QTableWidgetItem("Activity"));
    tableWidget->setItem(0,1,new QTableWidgetItem("Tom"));
    tableWidget->setItem(1,1,new QTableWidgetItem("2021-12-10"));
    tableWidget->setItem(2,1,new QTableWidgetItem("UK"));
    tableWidget->setItem(3,1,new QTableWidgetItem("Bicycle"));
    tableWidget->setMinimumWidth(230);

    verticalLayout->addWidget(tableWidget);

    // 又在右下放了一个表格
    QTableWidget *tableWidget1 = new QTableWidget(7,3);
    QStringList header2;
    header2<<"File name"<<"Size"<<"Duration";
    tableWidget1->setHorizontalHeaderLabels(header2);
    tableWidget1->setItem(0,0,new QTableWidgetItem("a.wmv"));
    tableWidget1->setItem(1,0,new QTableWidgetItem("b.wmv"));
    tableWidget1->setItem(2,0,new QTableWidgetItem("c.wmv"));
    tableWidget1->setItem(3,0,new QTableWidgetItem("d.wmv"));
    tableWidget1->setItem(4,0,new QTableWidgetItem("e.wmv"));
    tableWidget1->setItem(5,0,new QTableWidgetItem("f.wmv"));
    tableWidget1->setItem(6,0,new QTableWidgetItem("g.wmv"));
    tableWidget1->setItem(0,1,new QTableWidgetItem("20.3mb"));
    tableWidget1->setItem(1,1,new QTableWidgetItem("4.79mb"));
    tableWidget1->setItem(2,1,new QTableWidgetItem("3,09mb"));
    tableWidget1->setItem(3,1,new QTableWidgetItem("4.76mb"));
    tableWidget1->setItem(4,1,new QTableWidgetItem("4.91mb"));
    tableWidget1->setItem(5,1,new QTableWidgetItem("5.40mb"));
    tableWidget1->setItem(6,1,new QTableWidgetItem("7.82mb"));
    tableWidget1->setItem(0,2,new QTableWidgetItem("00:00:18"));
    tableWidget1->setItem(1,2,new QTableWidgetItem("00:00:15"));
    tableWidget1->setItem(2,2,new QTableWidgetItem("00:00:11"));
    tableWidget1->setItem(3,2,new QTableWidgetItem("00:00:9"));
    tableWidget1->setItem(4,2,new QTableWidgetItem("00:00:8"));
    tableWidget1->setItem(5,2,new QTableWidgetItem("00:00:9"));
    tableWidget1->setItem(6,2,new QTableWidgetItem("00:00:16"));

    tableWidget1->setMinimumWidth(230);

    verticalLayout->addWidget(tableWidget1);

    // 把表格布局放到整体布局中实现自适应
    gridLayout->addLayout(verticalLayout, 0, 1, 5, 1);

    QIcon *ico = new QIcon();
       ico->addPixmap(QPixmap("icons/mute.png"),QIcon::Normal,QIcon::On);
       ico->addPixmap(QPixmap("icons/pause.png"),QIcon::Normal,QIcon::Off);

    // add a menubar on the top.
    QMenu* Menu[10];
    this->setCentralWidget(centralwidget);
    menubar = new QMenuBar(this);
    menubar->setObjectName(QStringLiteral("menubar"));
    menubar->setGeometry(QRect(0, 0, 642, 21));
//    QAction *Brightness = new QAction("Brightness");
//    QAction *Contrast = new QAction("Contrast");
    QAction *setAttributes = new QAction(("setAttributes"), this);
    connect(setAttributes, SIGNAL(triggered()), this, SLOT(setting()));
    QAction *Localfile = new QAction("Local file");
    QAction *Externalfile = new QAction("External file");
    QAction *Edit = new QAction("Edit video");
    QAction *Dub = new QAction("Dub for video");
    QAction *Update = new QAction(("Update"),this);
    connect(Update, SIGNAL(triggered()), this, SLOT(Update()));
    QAction *Instruction = new QAction("Instruction");
    QAction *Maintance = new QAction("Maintance");
    Menu[0] = new QMenu("Setting");
    Menu[0]->addAction(setAttributes);
    Menu[1] = new QMenu("Import");
    Menu[1]->addAction(Localfile);
    Menu[1]->addAction(Externalfile);
    Menu[2] = new QMenu("Tools");
    Menu[2]->addAction(Edit);
    Menu[2]->addAction(Dub);
    Menu[3] = new QMenu("Help");
    Menu[3]->addAction(Update);
    Menu[3]->addAction(Instruction);
    Menu[3]->addAction(Maintance);
    menubar->addMenu(Menu[0]);
    menubar->addMenu(Menu[1]);
    menubar->addMenu(Menu[2]);
    menubar->addMenu(Menu[3]);
    this->setMenuBar(menubar);



}
