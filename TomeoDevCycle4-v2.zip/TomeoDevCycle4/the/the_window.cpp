#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include <QtGui>

#include <QFileSystemModel>
#include <QScreen>

#include <QVideoWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QMediaMetaData>
#include <QMediaPlaylist>
#include <QtCore/QDateTime>
#include "the_player.h"
#include "the_button.h"
#include "the_window.h"



MainWindow::MainWindow(std::string path): path(path) {
    videos = getInfoIn();
    createAll();
}

// read in videos and thumbnails to this directory
std::vector<TheButtonInfo> MainWindow::getInfoIn () {

    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
    QDir dir(QString::fromStdString(path) );
    QDirIterator it(dir);

    while (it.hasNext()) { // for all files

        QString f = it.next();

            if (f.contains("."))

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
#endif

            QString thumb = f.left( f .length() - 4) +".png";
            if (QFile(thumb).exists()) { // if a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read(); // read the thumbnail
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
                    }
                    else
                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
            }
            else
                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
        }
    }

    return out;
}

qint64 getAudioTime(const QString &filePath)
{
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly)) {
        qint64 fileSize = file.size();
        qint64 time = fileSize / (16000.0 * 2.0);
        file.close();
        return time;
    }
    return -1;
}

QPushButton *PausePlay;
void ThePlayer::toggleState(){
    if(playing == true){
        pause();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
        playing = false;
    }else{
        play();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPause));
        playing = true;
    }
}

//roll/random switch
QPushButton *buttonroll;
void ThePlayer::toggleState1(){
    if(buttonroll->isCheckable() == true){
        buttonroll->setIcon(QIcon("D:\\User Interface\\cw3\\our_cy2\\roll.png"));
        buttonroll->setCheckable(false);

    }else{
        buttonroll->setIcon(QIcon("D:\\User Interface\\cw3\\our_cy2\\single.png"));
        buttonroll->setCheckable(true);
    }
}

void MainWindow::createAll(){
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_5;
    QLabel *TitleImage;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *VideoWidget;
    QVBoxLayout *RightLayout;
    QHBoxLayout *Progress;
    QLCDNumber *TimeNumber;
    QSlider *ProgressBar;
    QComboBox *Speed;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *ButtonBack;
    // 播放/暂停按钮使用了槽函数，所以定义放在了main之前的函数里
    QPushButton *ButtonForward;
    QPushButton *ButtonVolumn;
    QSlider *VolumnBar;
    QVBoxLayout *verticalLayout_2;
    QLabel *Map;
    QVBoxLayout *InformationLayout;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    // the widget that will show the video
    QVideoWidget *videoWidget = new QVideoWidget;

    // the QMediaPlayer which controls the playback
    ThePlayer *player = new ThePlayer;
    player->setVideoOutput(videoWidget);
    player->setVolume(100);

    // a row of buttons
    QWidget *buttonWidget = new QWidget();
    // a list of the buttons
    //std::vector<TheButton*> buttons;
    // the buttons are arranged horizontally 这里的视频列表是竖着的
    QVBoxLayout *layout = new QVBoxLayout();
    buttonWidget->setLayout(layout);

    // create the video list
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    ProgressBar = new QSlider(Qt::Horizontal);
    VolumnBar = new QSlider(Qt::Horizontal);
    ProgressBar->setMinimumWidth(200);
    VolumnBar->setMinimumWidth(150);

    // 主窗口布局
    if (this->objectName().isEmpty())
        this->setObjectName(QStringLiteral("Main_for3"));
    this->resize(529, 442);
    centralwidget = new QWidget(this);
    centralwidget->setObjectName(QStringLiteral("centralwidget"));
    gridLayout = new QGridLayout(centralwidget);
    gridLayout->setObjectName(QStringLiteral("gridLayout"));

    // 标题图片，QLabel居中放在对应的布局中
    verticalLayout_5 = new QVBoxLayout();
    verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
    TitleImage = new QLabel(centralwidget);
    TitleImage->setObjectName(QStringLiteral("TitleImage"));
    TitleImage->setMaximumHeight(60);
    TitleImage->setMinimumHeight(60);
    TitleImage->setAlignment(Qt::AlignHCenter);
    // The relative path of the file is used.
    // Where "the" represents the name of the folder where the project files are located.
    // And place the required files in "Resources" folder.
    QPixmap *px = new QPixmap("../the/Resources/img1.png");
    *px = px->scaled(700,60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    TitleImage->setPixmap(*px);
    verticalLayout_5->addWidget(TitleImage);

    // 图片布局放到整体布局中实现自适应
    gridLayout->addLayout(verticalLayout_5, 0, 0, 1, 1);

    // 视频放在对应的布局中
    VideoWidget = new QVBoxLayout();
    VideoWidget->setObjectName(QStringLiteral("VideoWidget"));
    // the widget that will show the video
    VideoWidget->addWidget(videoWidget);
    gridLayout->addLayout(VideoWidget, 1, 0, 2, 1);

    // 播放时间，放在对应的布局中
    Progress = new QHBoxLayout();
    Progress->setObjectName(QStringLiteral("Progress"));
    TimeNumber = new QLCDNumber();
    TimeNumber->setObjectName(QStringLiteral("TimeNumber"));
    TimeNumber = new QLCDNumber(5);
    TimeNumber->setMaximumHeight(30);
    Progress->addWidget(TimeNumber);

    // 进度条，放在对应的布局中
    ProgressBar = new QSlider(Qt::Horizontal);
    ProgressBar->setObjectName(QStringLiteral("ProgressBar"));
    player->connect(player, &QMediaPlayer::durationChanged, ProgressBar, &QSlider::setMaximum);
    player->connect(player, &QMediaPlayer::positionChanged, ProgressBar, &QSlider::setValue);
    ProgressBar->connect(ProgressBar, &QSlider::sliderMoved, player, &QMediaPlayer::setPosition);
    ProgressBar->connect(ProgressBar, SIGNAL(valueChanged(int)), TimeNumber, SLOT(display(int)));
    Progress->addWidget(ProgressBar);

    // 倍速，放在对应的布局中
    Speed = new QComboBox();
    Speed->setObjectName(QStringLiteral("Speed"));
    Speed->addItem("0.5x", QVariant(0.5));
    Speed->addItem("1x", QVariant(1));
    Speed->addItem("1.5x", QVariant(1.5));
    Speed->addItem("2x", QVariant(2));
    Speed->addItem("2.5x", QVariant(2.5));
    Speed->addItem("3x", QVariant(3));
    Speed->setCurrentIndex(1);
    Speed->setMaximumWidth(80);
    Speed->connect(Speed, QOverload<int>::of(&QComboBox::activated), player, &QMediaPlayer::setPlaybackRate);
    Progress->addWidget(Speed);

    // 对应布局放到整体布局中实现响应式布局
    gridLayout->addLayout(Progress, 3, 0, 1, 1);

    // 按钮图标
    QIcon *ico = new QIcon();
       ico->addPixmap(QPixmap("icons/mute.png"),QIcon::Normal,QIcon::On);
       ico->addPixmap(QPixmap("icons/pause.png"),QIcon::Normal,QIcon::Off);

    //初始化布局
    horizontalLayout_2 = new QHBoxLayout();
    horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));

    //播放模式切换
    horizontalLayout_2->addStretch(1);
    buttonroll = new QPushButton();
    buttonroll->setIcon(QIcon("D:\\User Interface\\cw3\\our_cy2\\roll.png"));
    buttonroll->setIconSize(QSize(40, 40));
    buttonroll->connect(buttonroll,SIGNAL(clicked()),player,SLOT(toggleState1()));
    horizontalLayout_2->addWidget(buttonroll);

    // 后退按钮，放在对应的布局中
    horizontalLayout_2->addStretch(1);
    ButtonBack = new QPushButton(centralwidget);
    ButtonBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonBack->setIcon(ButtonBack->style()->standardIcon(QStyle::SP_MediaSkipBackward));
    ButtonBack->setIconSize(QSize(40, 40));
    ButtonBack->connect(ButtonBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonBack);

    // 播放/暂停按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    PausePlay = new QPushButton();
    PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
    PausePlay ->setIconSize(QSize(40, 40));
    PausePlay->connect(PausePlay, SIGNAL (clicked()), player, SLOT(toggleState()));
    horizontalLayout_2->addWidget(PausePlay);

    // 前进按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonForward = new QPushButton(centralwidget);
    ButtonForward->setObjectName(QStringLiteral("ButtonForward"));
    ButtonForward ->setIcon(ButtonForward->style()->standardIcon(QStyle::SP_MediaSkipForward));
    ButtonForward ->setIconSize(QSize(40, 40));
    ButtonForward ->connect(ButtonForward, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonForward);

    // 静音按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonVolumn = new QPushButton(centralwidget);
    ButtonVolumn->setObjectName(QStringLiteral("ButtonVolumn"));
    ButtonVolumn->setIcon(ButtonVolumn->style()->standardIcon(QStyle::SP_MediaVolumeMuted));
    ButtonVolumn->setIconSize(QSize(40, 40));
    ButtonVolumn->setCheckable(true);
    ButtonVolumn->connect(ButtonVolumn, &QPushButton::clicked, player, &QMediaPlayer::setMuted);
    horizontalLayout_2->addWidget(ButtonVolumn);

    // 音量调节按钮，放在对应的布局中
    VolumnBar = new QSlider(Qt::Horizontal);
    VolumnBar->setObjectName(QStringLiteral("VolumnBar"));
    VolumnBar->setOrientation(Qt::Horizontal);
    VolumnBar->connect(VolumnBar, &QSlider::sliderMoved, player, &QMediaPlayer::setVolume);
    VolumnBar->setValue(24);
    horizontalLayout_2->addWidget(VolumnBar);

    // 把播放等按钮的布局放在整体布局中实现自适应
    gridLayout->addLayout(horizontalLayout_2, 4, 0, 1, 1);


    // tell the player what buttons and videos are available
    player->setContent(&buttons, & videos);
    player->setPlaybackRate(0.25);

    //视频播放列表+对应布局
    horizontalLayout_3 = new QHBoxLayout();
    horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
    QScrollArea *scrollArea = new QScrollArea;
    scrollArea->setWidgetResizable(true);
    scrollArea->setWidget(buttonWidget);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setMinimumWidth(250);
    scrollArea->setMaximumWidth(250);
    horizontalLayout_3->addWidget(scrollArea);

    // 把视频播放列表布局放到整体布局中实现自适应
    gridLayout->addLayout(horizontalLayout_3, 0, 1, 2, 1);

    // add a table to RightLayout
    RightLayout = new QVBoxLayout();
    RightLayout->setObjectName(QStringLiteral("RightLayout"));
    QTableWidget *tableWidget = new QTableWidget(7,2);
    QStringList header;
    header<<"Month"<<"Description";
    tableWidget->setHorizontalHeaderLabels(header);
    tableWidget->setItem(0,0,new QTableWidgetItem("Author"));
    tableWidget->setItem(1,0,new QTableWidgetItem("Time"));
    tableWidget->setItem(2,0,new QTableWidgetItem("Location"));
    tableWidget->setItem(3,0,new QTableWidgetItem("Activity"));
    tableWidget->setItem(0,1,new QTableWidgetItem("Tom"));
    tableWidget->setItem(1,1,new QTableWidgetItem("2021-12-10"));
    tableWidget->setItem(2,1,new QTableWidgetItem("UK"));
    tableWidget->setItem(3,1,new QTableWidgetItem("Bicycle"));

    //添加第二个表格
    //添加标题
    QLabel *right_title = new QLabel();
    right_title->setText("Notes");
    right_title->setStyleSheet("font-size:25px");
    right_title->setContentsMargins(110,0,0,0);
    QTableWidget *tableWidget1 = new QTableWidget(4,2);
    QStringList header1;
    header1<<"Outline"<<"Details";
    tableWidget1->setHorizontalHeaderLabels(header1);

    //加入布局
    RightLayout->addWidget(tableWidget);
    RightLayout->addWidget(right_title);
    RightLayout->addWidget(tableWidget1);

    // 把表格布局放到整体布局中实现自适应
    gridLayout->addLayout(RightLayout, 2, 1, 3, 1);

    // 组件Map的布局
    verticalLayout_2 = new QVBoxLayout();
    verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
    Map = new QLabel(centralwidget);
    Map->setObjectName(QStringLiteral("Map"));
    // 删掉这行之后在这里写Map组件。
    verticalLayout_2->addWidget(Map);
    // 将Map所在的布局添加到全局实现响应式布局
    gridLayout->addLayout(verticalLayout_2, 5, 0, 1, 1);

    // 右下角的布局
    InformationLayout = new QVBoxLayout();
    InformationLayout->setObjectName(QStringLiteral("InformationLayout"));
    InformationLayout->setSizeConstraint(QLayout::SetMaximumSize);
    // 这个布局还不知道要放什么，所以没有声明任何组件。
    // 删掉这两行之后，写个组件然后InformationLayout->addWidget();
    gridLayout->addLayout(InformationLayout, 5, 1, 1, 1);

    // add a menubar on the top.
    this->setCentralWidget(centralwidget);
    QMenu* Menu[10];
    menubar = new QMenuBar(this);
    menubar->setObjectName(QStringLiteral("menubar"));
    menubar->setGeometry(QRect(0, 0, 529, 21));
    QAction *Brightness = new QAction("Brightness");
    QAction *Contrast = new QAction("Contrast");
    QAction *Localfile = new QAction("Local file");
    QAction *Externalfile = new QAction("External file");
    QAction *Edit = new QAction("Edit video");
    QAction *Dub = new QAction("Dub for video");
    QAction *Instruction = new QAction("Instruction");
    QAction *Maintance = new QAction("Maintance");
    Menu[0] = new QMenu("Setting");
    Menu[0]->addAction(Brightness);
    Menu[0]->addAction(Contrast);
    Menu[1] = new QMenu("Import");
    Menu[1]->addAction(Localfile);
    Menu[1]->addAction(Externalfile);
    Menu[2] = new QMenu("Tools");
    Menu[2]->addAction(Edit);
    Menu[2]->addAction(Dub);
    Menu[3] = new QMenu("Help");
    Menu[3]->addAction(Instruction);
    Menu[3]->addAction(Maintance);
    menubar->addMenu(Menu[0]);
    menubar->addMenu(Menu[1]);
    menubar->addMenu(Menu[2]);
    menubar->addMenu(Menu[3]);
    this->setMenuBar(menubar);

    statusbar = new QStatusBar(this);
    statusbar->setObjectName(QStringLiteral("statusbar"));
    this->setStatusBar(statusbar);

}

