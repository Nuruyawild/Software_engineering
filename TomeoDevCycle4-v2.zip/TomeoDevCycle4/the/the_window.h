#ifndef THE_WINDOW_H
#define THE_WINDOW_H

#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include <QtGui>

#include <QFileSystemModel>
#include <QScreen>

#include <QVideoWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QMediaMetaData>
#include <QMediaPlaylist>
#include <QtCore/QDateTime>
#include "the_player.h"
#include "the_button.h"


class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(std::string path);
private:
    std::vector<TheButtonInfo> getInfoIn ();
    std::string path;
    std::vector<TheButtonInfo> videos;
    std::vector<TheButton*> buttons;
    ThePlayer *player;
    bool loading = true;
    void createAll();
private slots:

};

#endif // THE_WINDOW_H
