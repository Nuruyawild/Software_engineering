#ifndef THE_WINDOW_H
#define THE_WINDOW_H

#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include <QtGui>

#include <QFileSystemModel>
#include <QScreen>

#include <QVideoWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QMediaMetaData>
#include <QMediaPlaylist>
#include <QtCore/QDateTime>
#include "the_player.h"
#include "the_button.h"


class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(std::string path);
private slots:
    void Update();
    void setting();
private:
    QWidget *centralwidget; // 不用管，Qt designer会用一个widget设计整个布局
    QGridLayout *gridLayout; // 栅格布局，用来实现整体自适应
    QHBoxLayout *horizontalLayout_2; // 四个按钮+音量调节滑轨的布局
    QHBoxLayout *horizontalLayout_4;//用户名+头像
    QHBoxLayout *horizontalLayout_5;//用户名+头像
    QPushButton *ButtonBack; // 上一个按钮
    // 播放/暂停按钮使用了槽函数，所以定义放在了main之前的函数里
    QPushButton *ButtonSeekForward;
    QPushButton *ButtonSeekBack;
    QPushButton *ButtonForward; // 下一个按钮
    QPushButton *ButtonVolumn; // 静音按钮
    QSlider *horizontalSlider; // 音量调节滑轨
    QVBoxLayout *verticalLayout; // 最右放表格的布局
    QHBoxLayout *Progress; // 播放时间，进度条滑轨和倍速的布局
    QLCDNumber *TimeNumber; // 播放时间显示
    QSlider *horizontalSlider_2; // 进度条
    QComboBox *Speed; // 倍速
    QVBoxLayout *verticalLayout_2; // 最底部播放列表的布局
    QVBoxLayout *InformationLayout; // 标题图片的布局
    QLabel *label; // 标题图片
    QLabel *Map;
    QLabel *UserImage;
    QLabel *Username;
    QVBoxLayout *VideoWidget; // 视频播放界面的布局
    QMenuBar *menubar; // 顶部工具栏
    QStatusBar *statusbar; // 状态栏，Qt designer自动生成，暂时没用到
    std::vector<TheButtonInfo> getInfoIn ();
    std::string path;
    std::vector<TheButtonInfo> videos;
    std::vector<TheButton*> buttons;
    ThePlayer *player;
    QVideoWidget *videoWidget;
    QVBoxLayout *verticalLayout_5;
    QLabel *TitleImage;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *RightLayout;
    QSlider *ProgressBar;
    // 播放/暂停按钮使用了槽函数，所以定义放在了main之前的函数里
    QSlider *VolumnBar;
    bool loading = true;
    void createAll();

};

#endif // THE_WINDOW_H
