#ifndef MEDIA_H
#define MEDIA_H

#include <QVideoWidget>

class Media : public QVideoWidget{
    Q_OBJECT
public:
public slots:
    void mouseDoubleClickEvent(QMouseEvent *event);
};

#endif // MEDIA_H
