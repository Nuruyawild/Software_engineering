//    ______
//   /_  __/___  ____ ___  ___  ____
//    / / / __ \/ __ `__ \/ _ \/ __ \
//   / / / /_/ / / / / / /  __/ /_/ /
//  /_/  \____/_/ /_/ /_/\___/\____/
//              video for sports enthusiasts...
//
//  2811 cw3 : twak 11/11/2021
//

#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtGui>
#include <QFileSystemModel>
#include "the_player.h"
#include "the_button.h"
#include "the_window.h"
#include "logindialog.h"


int main(int argc, char *argv[]) {

    // let's just check that Qt is operational first
    qDebug() << "Qt version: " << QT_VERSION_STR << endl;

    // create the Qt Application
    QApplication app(argc, argv);
    MainWindow* window = new MainWindow(std::string(argv[1]));
    window->setWindowTitle("Tomeo");
    window->setMinimumSize(900, 700);
    LoginDialog dlg;

    if (dlg.exec() == QDialog::Accepted)
        {
            window->show();
            return app.exec();
        }
    else
        {
            return 0;
        }
}
