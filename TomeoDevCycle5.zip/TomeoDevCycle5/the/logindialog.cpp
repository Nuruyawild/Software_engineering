#include "logindialog.h"


#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>

LoginDialog::LoginDialog(QWidget *parent):QDialog(parent)
{
    userLabel = new QLabel(this);
    userLabel->move(70, 80);
    userLabel->setText(tr("Username"));

    userEditLine = new QLineEdit(this);
    userEditLine->move(140, 80);
    userEditLine->setPlaceholderText(tr("Enter username"));

    pwdLabel = new QLabel(this);
    pwdLabel->move(70, 130);
    pwdLabel->setText(tr("Password"));

    pwdEditLine = new QLineEdit(this);
    pwdEditLine->move(140, 130);
    pwdEditLine->setPlaceholderText(tr("Enter the password"));

    loginBtn = new QPushButton(this);
    loginBtn->move(50, 200);
    loginBtn->setText(tr("Login"));

    exitBtn = new QPushButton(this);
    exitBtn->move(210, 200);
    exitBtn->setText(tr("Quit"));
    //singal and slot
    connect(loginBtn, &QPushButton::clicked, this, &LoginDialog::login);
    connect(exitBtn, &QPushButton::clicked, this, &LoginDialog::close);


}

LoginDialog::~LoginDialog()
{

}

void LoginDialog::login()
{
    //Determine whether the user name and password are correct
    if (userEditLine->text().trimmed() == tr("tom") &&
            pwdEditLine->text() == tr("123456"))
    {
        accept();
    }
    else
    {
        QMessageBox::warning(this, tr("Alert"), tr("Username or password is incorrect"), QMessageBox::Yes);
    }

    userEditLine->clear();
    pwdEditLine->clear();
    userEditLine->setFocus();
}
