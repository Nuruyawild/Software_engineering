#include <iostream>
#include <QCoreApplication>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <vector>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <QLCDNumber>
#include <QComboBox>
#include <QIcon>
#include <QScrollArea>
#include <string>
#include <vector>
#include <QtCore/QDirIterator>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QProgressBar>
#include <QtGui>
#include <QFileDialog>
#include <QFileSystemModel>
#include <QScreen>

#include <QVideoWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QMediaMetaData>
#include <QMediaPlaylist>
#include <QtCore/QDateTime>
#include "the_player.h"
#include "the_button.h"
#include "the_window.h"



MainWindow::MainWindow(std::string path): path(path) {
    videos = getInfoIn();
    createAll();
}

// read in videos and thumbnails to this directory
std::vector<TheButtonInfo> MainWindow::getInfoIn () {

    std::vector<TheButtonInfo> out =  std::vector<TheButtonInfo>();
    QDir dir(QString::fromStdString(path) );
    QDirIterator it(dir);

    while (it.hasNext()) { // for all files

        QString f = it.next();

            if (f.contains("."))

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4") || f.contains("MOV"))  { // mac/linux
#endif

            QString thumb = f.left( f .length() - 4) +".png";
            if (QFile(thumb).exists()) { // if a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read(); // read the thumbnail
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite)); // voodoo to create an icon for the button
                        QUrl* url = new QUrl(QUrl::fromLocalFile( f )); // convert the file location to a generic url
                        out . push_back(TheButtonInfo( url , ico  ) ); // add to the output list
                    }
                    else
                        qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb << endl;
            }
            else
                qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb << endl;
        }
    }

    return out;
}

qint64 getAudioTime(const QString &filePath)
{
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly)) {
        qint64 fileSize = file.size();
        qint64 time = fileSize / (16000.0 * 2.0);
        file.close();
        return time;
    }
    return -1;
}

QPushButton *buttonroll;
QPushButton *PausePlay;
void ThePlayer::toggleState(){
    if(playing == true){
        pause();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
        playing = false;
    }else{
        play();
        PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPause));
        playing = true;
    }
}

//roll/random switch
void ThePlayer::toggleState1(){
    if(buttonroll->isCheckable() == true){
        buttonroll->setIcon(QIcon("../the/Resources/roll.png"));
        buttonroll->setCheckable(false);

    }else{
        buttonroll->setIcon(QIcon("../the/Resources/single.png"));
        buttonroll->setCheckable(true);
    }
}


// 菜单栏中update的弹窗
void MainWindow::Update() {

    QVBoxLayout* lay = new QVBoxLayout;

    QLabel *label_text = new QLabel;
//    QLabel *label_button = new QLabel;
    //QPixmap pm(":/help.png"); // <- path to image file
    //label->setPixmap(pm);
    label_text->setScaledContents(true);
    label_text->setMaximumSize(700,400);
    label_text->setText("<em><strong>Please choose the version you want to update to:<\strong><\em>");

    QPushButton *version1 = new QPushButton("1.1.2");
    QPushButton *version2 = new QPushButton("1.1.3");
    QPushButton *version3 = new QPushButton("1.2.1");
    QHBoxLayout *hor_text = new QHBoxLayout;
    hor_text->addWidget(label_text);
    QHBoxLayout *hor_button = new QHBoxLayout;
    hor_button->setMargin(0);
    hor_button->addWidget(version1);
    hor_button->addWidget(version2);
    hor_button->addWidget(version3);

    lay->addLayout(hor_text);
    lay->addLayout(hor_button);
    //lay->addWidget(label_text);
//    lay->addWidget(label_button);
    lay->setMargin(20);
    lay->setSpacing(15);
    QDialog dialog(this);
    dialog.setModal(true);
    dialog.setLayout(lay);
    dialog.setWindowTitle("Update");
    dialog.setWindowFlags(windowFlags()&~Qt::WindowContextHelpButtonHint);
    dialog.exec();
}


//菜单栏中setting的弹窗
void MainWindow::setting() {

    QSlider *bri_setting = new QSlider(Qt::Horizontal);
    bri_setting->setRange(-100, 100);
    QLabel *bri_label=new QLabel;
    bri_label->setText("Brightness");


    QSlider *contrast_setting = new QSlider(Qt::Horizontal);
    contrast_setting->setRange(-100, 100);
    QLabel *con_label=new QLabel;
    con_label->setText("Contrast");

    QSlider *hue_setting = new QSlider(Qt::Horizontal);
    hue_setting->setRange(-100, 100);
    QLabel *hue_label=new QLabel;
    hue_label->setText("Hue");

    QGridLayout *settinglayout = new QGridLayout;
    QLabel *setting_title=new QLabel;
    setting_title->setText("<em><strong>Setting Your Video Attribute<\strong><\em>");
    settinglayout->addWidget(setting_title,0,1,1,4);
    settinglayout->addWidget(hue_label,1,0,1,2);
    settinglayout->addWidget(con_label,2,0,1,2);
    settinglayout->addWidget(bri_label,3,0,1,2);
    settinglayout->addWidget(hue_setting,1,2,1,5);
    settinglayout->addWidget(contrast_setting,2,2,1,5);
    settinglayout->addWidget(bri_setting,3,2,1,5);

    QDialog *video_setDialog = new QDialog;
    video_setDialog->setWindowTitle(tr("Video Attribute Setting"));
    video_setDialog->setWindowFlags(windowFlags()&~Qt::WindowContextHelpButtonHint);
    video_setDialog->setLayout(settinglayout);
    video_setDialog->exec();

}


void MainWindow::changeColor(){
    if(buttoncolor->isCheckable() == true){
        buttoncolor->setIcon(QIcon("../the/Resources/dark.png"));
        window()->setStyleSheet("background-color: grey");
        buttoncolor->setCheckable(false);
    }
    else{
        buttoncolor->setIcon(QIcon("../the/Resources/day.png"));
        window()->setStyleSheet("");
        buttoncolor->setCheckable(true);
    }
}





void MainWindow::createAll(){

    // the widget that will show the video
    QVideoWidget *videoWidget = new QVideoWidget;

    // the QMediaPlayer which controls the playback
    ThePlayer *player = new ThePlayer;
    player->setVideoOutput(videoWidget);
    player->setVolume(100);

    // a row of buttons
    QWidget *buttonWidget = new QWidget();
    // a list of the buttons
    //std::vector<TheButton*> buttons;
    // the buttons are arranged horizontally 这里的视频列表是竖着的
    QVBoxLayout *layout = new QVBoxLayout();
    buttonWidget->setLayout(layout);

    // create the video list
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* ))); // when clicked, tell the player to play.
        buttons.push_back(button);
        layout->addWidget(button);
        button->init(&videos.at(i));
    }

    ProgressBar = new QSlider(Qt::Horizontal);
    VolumnBar = new QSlider(Qt::Horizontal);
    ProgressBar->setMinimumWidth(230);
    VolumnBar->setMinimumWidth(150);

    // 主窗口布局
    if (this->objectName().isEmpty())
        this->setObjectName(QStringLiteral("Main_for3"));
    this->resize(529, 442);
    centralwidget = new QWidget(this);
    centralwidget->setObjectName(QStringLiteral("centralwidget"));
    gridLayout = new QGridLayout(centralwidget);
    gridLayout->setObjectName(QStringLiteral("gridLayout"));

    // 标题图片，QLabel居中放在对应的布局中
    verticalLayout_5 = new QVBoxLayout();
    verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
    TitleImage = new QLabel(centralwidget);
    TitleImage->setObjectName(QStringLiteral("TitleImage"));
    TitleImage->setMaximumHeight(60);
    TitleImage->setMinimumHeight(60);
    TitleImage->setAlignment(Qt::AlignHCenter);
    // The relative path of the file is used.
    // Where "the" represents the name of the folder where the project files are located.
    // And place the required files in "Resources" folder.
    QPixmap *px = new QPixmap("../the/Resources/img1.png");
    *px = px->scaled(520,60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    TitleImage->setPixmap(*px);
    verticalLayout_5->addWidget(TitleImage);

    // 图片布局放到整体布局中实现自适应
    gridLayout->addLayout(verticalLayout_5, 0, 0, 1, 1);

    // 视频放在对应的布局中
    VideoWidget = new QVBoxLayout();
    VideoWidget->setObjectName(QStringLiteral("VideoWidget"));
    // the widget that will show the video
    VideoWidget->addWidget(videoWidget);
    gridLayout->addLayout(VideoWidget, 1, 0, 2, 1);

    // 播放时间，放在对应的布局中
    Progress = new QHBoxLayout();
    Progress->setObjectName(QStringLiteral("Progress"));
    TimeNumber = new QLCDNumber();
    TimeNumber->setObjectName(QStringLiteral("TimeNumber"));
    TimeNumber = new QLCDNumber(5);
    TimeNumber->setMaximumHeight(30);
    Progress->addWidget(TimeNumber);

    // 进度条，放在对应的布局中
    ProgressBar = new QSlider(Qt::Horizontal);
    ProgressBar->setObjectName(QStringLiteral("ProgressBar"));
    player->connect(player, &QMediaPlayer::durationChanged, ProgressBar, &QSlider::setMaximum);
    player->connect(player, &QMediaPlayer::positionChanged, ProgressBar, &QSlider::setValue);
    ProgressBar->connect(ProgressBar, &QSlider::sliderMoved, player, &QMediaPlayer::setPosition);
    ProgressBar->connect(ProgressBar, SIGNAL(valueChanged(int)), TimeNumber, SLOT(display(int)));
    Progress->addWidget(ProgressBar);

    // 倍速，放在对应的布局中
    Speed = new QComboBox();
    Speed->setObjectName(QStringLiteral("Speed"));
    Speed->addItem("0.5x", QVariant(0.5));
    Speed->addItem("1x", QVariant(1));
    Speed->addItem("1.5x", QVariant(1.5));
    Speed->addItem("2x", QVariant(2));
    Speed->addItem("2.5x", QVariant(2.5));
    Speed->addItem("3x", QVariant(3));
    Speed->setCurrentIndex(1);
    Speed->setMaximumWidth(80);
    Speed->connect(Speed, QOverload<int>::of(&QComboBox::activated), player, &QMediaPlayer::setPlaybackRate);
    Progress->addWidget(Speed);

    // 对应布局放到整体布局中实现响应式布局
    gridLayout->addLayout(Progress, 3, 0, 1, 1);

    // 按钮图标
    QIcon *ico = new QIcon();
       ico->addPixmap(QPixmap("icons/mute.png"),QIcon::Normal,QIcon::On);
       ico->addPixmap(QPixmap("icons/pause.png"),QIcon::Normal,QIcon::Off);

    //初始化布局
    horizontalLayout_2 = new QHBoxLayout();
    horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));

    //day and dark
    horizontalLayout_2->addStretch(2);
    buttoncolor = new QPushButton();
    buttoncolor->connect(buttoncolor,SIGNAL(clicked()),this,SLOT(changeColor()));
    buttoncolor->setIcon(QIcon("../the/Resources/day.png"));
    horizontalLayout_2->addWidget(buttoncolor);

    //播放模式切换
    horizontalLayout_2->addStretch(1);
    buttonroll = new QPushButton();
    buttonroll->setIcon(QIcon("../the/Resources/roll.png"));
    buttonroll->setIconSize(QSize(40, 40));
    buttonroll->connect(buttonroll,SIGNAL(clicked()),player,SLOT(toggleState1()));
    horizontalLayout_2->addWidget(buttonroll);

    // 后退按钮，放在对应的布局中
    horizontalLayout_2->addStretch(1);
    ButtonBack = new QPushButton(centralwidget);
    ButtonBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonBack->setIcon(ButtonBack->style()->standardIcon(QStyle::SP_MediaSkipBackward));
    ButtonBack->setIconSize(QSize(40, 40));
    ButtonBack->connect(ButtonBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonBack);


    //切换上一个视频按钮
    horizontalLayout_2->addStretch(1);
    ButtonSeekBack = new QPushButton(centralwidget);
    ButtonSeekBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonSeekBack->setIcon(ButtonSeekBack->style()->standardIcon(QStyle::SP_MediaSeekBackward));
    ButtonSeekBack->setIconSize(QSize(40, 40));
    ButtonSeekBack->connect(ButtonSeekBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonSeekBack);

    // 播放/暂停按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    PausePlay = new QPushButton();
    PausePlay->setIcon(PausePlay ->style()->standardIcon(QStyle::SP_MediaPlay));
    PausePlay ->setIconSize(QSize(40, 40));
    PausePlay->connect(PausePlay, SIGNAL (clicked()), player, SLOT(toggleState()));
    horizontalLayout_2->addWidget(PausePlay);

    //切换到下一个视频按钮
    horizontalLayout_2->addStretch(2);
    ButtonSeekBack = new QPushButton(centralwidget);
    ButtonSeekBack->setObjectName(QStringLiteral("ButtonBack"));
    ButtonSeekBack->setIcon(ButtonSeekBack->style()->standardIcon(QStyle::SP_MediaSeekForward));
    ButtonSeekBack->setIconSize(QSize(40, 40));
    ButtonSeekBack->connect(ButtonSeekBack, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonSeekBack);

    // 前进按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonForward = new QPushButton(centralwidget);
    ButtonForward->setObjectName(QStringLiteral("ButtonForward"));
    ButtonForward ->setIcon(ButtonForward->style()->standardIcon(QStyle::SP_MediaSkipForward));
    ButtonForward ->setIconSize(QSize(40, 40));
    ButtonForward ->connect(ButtonForward, &QPushButton::clicked, player, &QMediaPlayer::play);
    horizontalLayout_2->addWidget(ButtonForward);

    // 静音按钮，放在对应的布局中
    horizontalLayout_2->addStretch(2);
    ButtonVolumn = new QPushButton(centralwidget);
    ButtonVolumn->setObjectName(QStringLiteral("ButtonVolumn"));
    ButtonVolumn->setIcon(ButtonVolumn->style()->standardIcon(QStyle::SP_MediaVolumeMuted));
    ButtonVolumn->setIconSize(QSize(40, 40));
    ButtonVolumn->setCheckable(true);
    ButtonVolumn->connect(ButtonVolumn, &QPushButton::clicked, player, &QMediaPlayer::setMuted);
    horizontalLayout_2->addWidget(ButtonVolumn);

    // 音量调节按钮，放在对应的布局中
    VolumnBar = new QSlider(Qt::Horizontal);
    VolumnBar->setObjectName(QStringLiteral("VolumnBar"));
    VolumnBar->setOrientation(Qt::Horizontal);
    VolumnBar->connect(VolumnBar, &QSlider::sliderMoved, player, &QMediaPlayer::setVolume);
    VolumnBar->setValue(24);
    horizontalLayout_2->addWidget(VolumnBar);

    // 把播放等按钮的布局放在整体布局中实现自适应
    gridLayout->addLayout(horizontalLayout_2, 4, 0, 1, 1);


    // tell the player what buttons and videos are available
    player->setContent(&buttons, & videos);
    player->setPlaybackRate(0.25);

    //用户头像＋用户名
    horizontalLayout_5 = new QHBoxLayout();
    horizontalLayout_4 = new QHBoxLayout();
    UserImage = new QLabel(centralwidget);
    UserImage->setObjectName(QStringLiteral("TitleImage"));
    UserImage->setMaximumHeight(60);
    UserImage->setMinimumHeight(60);
    UserImage->setAlignment(Qt::AlignLeft);
    Username = new QLabel(centralwidget);
    Username->setText("Username: Tom");
    Username->setAlignment(Qt::AlignCenter);
//    QFrame *frame = new QFrame();
//    frame->setFrameStyle({border:1px solid rgb(0,255,0)};);
//    frame->setLayout(horizontalLayout_4




    // The relative path of the file is used.
    // Where "the" represents the name of the folder where the project files are located.
    // And place the required files in "Resources" folder.
    QPixmap *user = new QPixmap("../the/Resources/user.png");
    *user = user->scaled(60,60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    UserImage->setPixmap(*user);
    horizontalLayout_4->addWidget(UserImage);
    horizontalLayout_5->addWidget(Username);
    gridLayout->addLayout(horizontalLayout_4, 0, 1, 1, 1);
    QWidget *wid = new QWidget();
    wid->setLayout(horizontalLayout_5);
    horizontalLayout_4->addWidget(wid);
    wid->setStyleSheet(QString::fromUtf8("border:1px solid black"));
    horizontalLayout_4->setStretch(1,1);
    horizontalLayout_4->setStretch(2,2);

    horizontalLayout_5->setMargin(10);


    //视频播放列表+对应布局
    horizontalLayout_3 = new QHBoxLayout();
    horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
    QScrollArea *scrollArea = new QScrollArea;
    scrollArea->setWidgetResizable(true);
    scrollArea->setWidget(buttonWidget);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setMinimumWidth(250);
    scrollArea->setMaximumWidth(250);
    horizontalLayout_3->addWidget(scrollArea);

    // 把视频播放列表布局放到整体布局中实现自适应
    gridLayout->addLayout(horizontalLayout_3, 1, 1, 2, 1);

    // add a table to RightLayout
    RightLayout = new QVBoxLayout();
    RightLayout->setObjectName(QStringLiteral("RightLayout"));
    QTableWidget *tableWidget = new QTableWidget(7,2);
    QStringList header;
    header<<"Month"<<"Description";
    tableWidget->setHorizontalHeaderLabels(header);
    tableWidget->setItem(0,0,new QTableWidgetItem("Author"));
    tableWidget->setItem(1,0,new QTableWidgetItem("Time"));
    tableWidget->setItem(2,0,new QTableWidgetItem("Location"));
    tableWidget->setItem(3,0,new QTableWidgetItem("Activity"));
    tableWidget->setItem(0,1,new QTableWidgetItem("Tom"));
    tableWidget->setItem(1,1,new QTableWidgetItem("2021-12-10"));
    tableWidget->setItem(2,1,new QTableWidgetItem("UK"));
    tableWidget->setItem(3,1,new QTableWidgetItem("Bicycle"));

    //添加第二个表格
    //添加标题
    QLabel *right_title = new QLabel();
    right_title->setText("Notes");
    right_title->setStyleSheet("font-size:25px");
    right_title->setContentsMargins(110,0,0,0);
    QTableWidget *tableWidget1 = new QTableWidget(7,3);
    QStringList header2;
    header2<<"File name"<<"Size"<<"Duration";
    tableWidget1->setHorizontalHeaderLabels(header2);
    tableWidget1->setItem(0,0,new QTableWidgetItem("a.wmv"));
    tableWidget1->setItem(1,0,new QTableWidgetItem("b.wmv"));
    tableWidget1->setItem(2,0,new QTableWidgetItem("c.wmv"));
    tableWidget1->setItem(3,0,new QTableWidgetItem("d.wmv"));
    tableWidget1->setItem(4,0,new QTableWidgetItem("e.wmv"));
    tableWidget1->setItem(5,0,new QTableWidgetItem("f.wmv"));
    tableWidget1->setItem(6,0,new QTableWidgetItem("g.wmv"));
    tableWidget1->setItem(0,1,new QTableWidgetItem("20.3mb"));
    tableWidget1->setItem(1,1,new QTableWidgetItem("4.79mb"));
    tableWidget1->setItem(2,1,new QTableWidgetItem("3,09mb"));
    tableWidget1->setItem(3,1,new QTableWidgetItem("4.76mb"));
    tableWidget1->setItem(4,1,new QTableWidgetItem("4.91mb"));
    tableWidget1->setItem(5,1,new QTableWidgetItem("5.40mb"));
    tableWidget1->setItem(6,1,new QTableWidgetItem("7.82mb"));
    tableWidget1->setItem(0,2,new QTableWidgetItem("00:00:18"));
    tableWidget1->setItem(1,2,new QTableWidgetItem("00:00:15"));
    tableWidget1->setItem(2,2,new QTableWidgetItem("00:00:11"));
    tableWidget1->setItem(3,2,new QTableWidgetItem("00:00:9"));
    tableWidget1->setItem(4,2,new QTableWidgetItem("00:00:8"));
    tableWidget1->setItem(5,2,new QTableWidgetItem("00:00:9"));
    tableWidget1->setItem(6,2,new QTableWidgetItem("00:00:16"));
    tableWidget1->setHorizontalHeaderLabels(header2);

    //加入布局
    RightLayout->addWidget(tableWidget);
    RightLayout->addWidget(right_title);
    RightLayout->addWidget(tableWidget1);

    // 把表格布局放到整体布局中实现自适应
    gridLayout->addLayout(RightLayout, 3, 1, 3, 1);

    // 组件Map的布局
    verticalLayout_2 = new QVBoxLayout();
    verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
    verticalLayout_2->setMargin(0);
    Map = new QLabel(centralwidget);
    Map->setObjectName(QStringLiteral("Map"));
    Map->setStyleSheet(QString::fromUtf8("border:1px solid black"));
    Map->setMaximumHeight(130);
    Map->setMinimumHeight(130);
    Map->setAlignment(Qt::AlignCenter);
    // 删掉这行之后在这里写Map组件。
    // The relative path of the file is used.
    // Where "the" represents the name of the folder where the project files are located.
    // And place the required files in "Resources" folder.
    QPixmap *map = new QPixmap("../the/Resources/Map.jpg");
    *map = map->scaled(900,130, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    Map->setPixmap(*map);
    verticalLayout_2->addWidget(Map);
    // 将Map所在的布局添加到全局实现响应式布局
    gridLayout->addLayout(verticalLayout_2, 5, 0, 1, 1);

//    // 右下角的布局
//    InformationLayout = new QVBoxLayout();
//    InformationLayout->setObjectName(QStringLiteral("InformationLayout"));
//    InformationLayout->setSizeConstraint(QLayout::SetMaximumSize);
//    // 这个布局还不知道要放什么，所以没有声明任何组件。
//    // 删掉这两行之后，写个组件然后InformationLayout->addWidget();
//    gridLayout->addLayout(InformationLayout, 5, 1, 1, 1);

    // add a menubar on the top.
    this->setCentralWidget(centralwidget);
    QMenu* Menu[10];
    menubar = new QMenuBar(this);
    menubar->setObjectName(QStringLiteral("menubar"));
    menubar->setGeometry(QRect(0, 0, 529, 21));
    QAction *setAttributes = new QAction(("setAttributes"), this);
    connect(setAttributes, SIGNAL(triggered()), this, SLOT(setting()));
    QAction *import = new QAction(tr("&Import Local Folder"), this);
    connect(import, SIGNAL(triggered()), this, SLOT(importfile()));
    QAction *Externalfile = new QAction("External file");
    QAction *Edit = new QAction("Edit video");
    QAction *Dub = new QAction("Dub for video");
    QAction *Update = new QAction(("Update"),this);
    connect(Update, SIGNAL(triggered()), this, SLOT(Update()));
    QAction *Maintance = new QAction("Maintance");
    Menu[0] = new QMenu("Setting");
    Menu[0]->addAction(setAttributes);
    Menu[1] = new QMenu("Import");
    Menu[1]->addAction(import);
    Menu[1]->addAction(Externalfile);
    Menu[2] = new QMenu("Tools");
    Menu[2]->addAction(Edit);
    Menu[2]->addAction(Dub);
    Menu[3] = new QMenu("Help");
    Menu[3]->addAction(Update);
    Menu[3]->addAction(Maintance);
    menubar->addMenu(Menu[0]);
    menubar->addMenu(Menu[1]);
    menubar->addMenu(Menu[2]);
    menubar->addMenu(Menu[3]);
    this->setMenuBar(menubar);

//    statusbar = new QStatusBar(this);
//    statusbar->setObjectName(QStringLiteral("statusbar"));
//    this->setStatusBar(statusbar);

}

void MainWindow::importfile() {
    QString destination = QString::fromStdString(path);
    QString source = QFileDialog::getExistingDirectory(this, tr("Open Directory"),QDir::homePath());
    QStringList path = source.split("/");
    QString directory = path.at(path.size() - 1);
    destination = destination + QDir::separator() + directory;
    QDir sourDir(source);
    QDir destinationDir(destination);
    if (!sourDir.exists())
        return;
    if (!destinationDir.exists()){
        destinationDir.mkdir(destination);
    }
    foreach (QString file, sourDir.entryList(QDir::Files)) {
        QFile::copy(source + QDir::separator() + file, destination+ QDir::separator() + file);
    }
}


